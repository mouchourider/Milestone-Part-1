#include <pthread.h>
#include <iostream>

using namespace std;

struct MyParams
{
	int x;
	char y;
};
void* thread_func(void* arg)
{
	struct MyParams* params = (struct MyParams*) arg;
	for (int i = 0; i < params->x; ++i)	{
		cout << params->y;
	}
	cout << endl;
	params.x = 0;
	params.y = '@';
	return params;
}

int main()
{
	struct MyParams* params = new MyParams();
	params.x = 10;
	params.y = '*';
	pthread_t trid;
	pthread_start(&trid, nullptr, thread_func, params);
	pthread_join(&trid, &params);
	return 0;
}