#include <pthread.h>
#include <iostream>

using namespace std;

struct MyParams
{
	int x;
	char y;
};
void* thread_func(void* arg)
{
	struct MyParams* params = (struct MyParams*) arg;
	for (int i = 0; i < params->x; ++i)	{
		cout << params->y;
	}
	cout << endl;
	delete params;
	return nullptr;
}

int main()
{
	struct MyParams* params = new MyParams();
	params.x = 10;
	params.y = '*';
	pthread_t trid;
	pthread_start(&trid, nullptr, thread_func, params);
	
	return 0;
}