#include <pthread.h>
#include <iostream>

using namespace std;

void* thread_func(void* arg)
{
	cout << "Thread!" << endl;
	return nullptr;
}

int main()
{
	pthread_t trid;
	pthread_start(&trid, nullptr, thread_func, nullptr);
	
	return 0;
}